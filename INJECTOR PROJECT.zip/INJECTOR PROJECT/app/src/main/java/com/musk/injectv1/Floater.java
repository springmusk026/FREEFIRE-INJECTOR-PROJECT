package com.musk.injectv1;


import android.annotation.TargetApi;
import android.app.AlertDialog;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.AsyncTask;
import android.os.Build;
import android.os.IBinder;
import android.text.Html;
import android.text.InputFilter;
import android.text.InputType;
import android.text.method.DigitsKeyListener;
import android.util.Base64;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import eu.chainfire.libsuperuser.Shell;
import java.io.File;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.UUID;
import static android.view.ViewGroup.LayoutParams.WRAP_CONTENT;
import static android.view.ViewGroup.LayoutParams.MATCH_PARENT;
import static android.widget.RelativeLayout.ALIGN_PARENT_RIGHT;
import android.view.Gravity;
import android.net.Uri;
import android.annotation.SuppressLint;
import android.graphics.PorterDuff;

public class Floater extends Service {

	     private Floater AdError;
    public static final int CACHE_ERROR_CODE = 2002;
	public static final int INTERNAL_ERROR_2003 = 2003;
    private ESPView overlayView;
	
    public View mFloatingView;
    private Button close;

    private Button kill;
    private LinearLayout mButtonPanel;
    public RelativeLayout mCollapsed;
    public LinearLayout mExpanded;
    public LinearLayout mSettings;
    private RelativeLayout mRootContainer;
    public WindowManager mWindowManager;
    public WindowManager.LayoutParams params;
    private LinearLayout patches;
    private FrameLayout rootFrame;
    private ImageView startimage ,  musk;
    private LinearLayout view1;
    private LinearLayout view2;
    private AlertDialog alert;
    private EditText edittextvalue;
    private GradientDrawable gdMenuBody, gdAnimation = new GradientDrawable();
    private static final String TAG = "Mod Menu";
    private final float MENU_CORNER = 5f;
    public TextView textView , online ;
    private WindowManager.LayoutParams espParams;
    
    private native String Title();

    private native String Heading();

    public static  native String Icon();
	
	private native void Stop();

	private native boolean IsConnected();
	
    public native void Changes(int feature, int value);

    public static native void DrawOn(ESPView eSPView, Canvas canvas);

    private native String[] MenuPro();
	
    @Override
    public IBinder onBind(Intent p1) {
        return null;
    }
	
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return super.onStartCommand(intent, flags, startId);
	}
	
    private int getLayoutType() {
        if (Build.VERSION.SDK_INT >= 26) {
            return 2038;
        }
        if (Build.VERSION.SDK_INT >= 24) {
            return AdError.CACHE_ERROR_CODE;
        }
        if (Build.VERSION.SDK_INT >= 23) {
            return 2005;
        }
        return AdError.INTERNAL_ERROR_2003;
    }

    private void DrawCanvas() {
        this.overlayView = new ESPView(getBaseContext());
        WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams(-1, -1, getLayoutType(), 1080, -3);
        layoutParams.gravity = 8388659;
        layoutParams.x = 0;
        layoutParams.y = 100;
        this.mWindowManager.addView(this.overlayView, layoutParams);
    }
	
	@Override
	public void onCreate() {
		super.onCreate();
		initFloating();
		
		
		
	}
	private static String getArch(String str) {
        if (str.contains("lib/arm64")) {
            return "arm64";
        }
        if (str.contains("lib/arm")) {
            return "armv7";
        }
        return str.contains("lib/x86") ? "x86" : "";
    }
	
	
	private static String currArch() {
        String arch = System.getProperty("os.arch");
        if (arch == null) {
            return "armeabi-v7a";
        }
        if (arch.contains("armv8l") && Build.SUPPORTED_64_BIT_ABIS.length <= 0) {
            return "armeabi-v7a";
        }
        if (arch.contains("aarch64") || arch.contains("armv8l")) {
            return "arm64-v8a";
        }
        return "armeabi-v7a";
    }
	
	private void initFloating() {
        rootFrame = new FrameLayout(getBaseContext()); // Global markup
        mRootContainer = new RelativeLayout(getBaseContext()); // Markup on which two markups of the icon and the menu itself will be placed
        mCollapsed = new RelativeLayout(getBaseContext()); // Markup of the icon (when the menu is minimized)
        mExpanded = new LinearLayout(getBaseContext()); // Menu markup (when the menu is expanded)
        patches = new LinearLayout(getBaseContext());
        mButtonPanel = new LinearLayout(getBaseContext()); // Layout of option buttons (when the menu is expanded)

        RelativeLayout relativeLayout = new RelativeLayout(this);
        relativeLayout.setLayoutParams(new RelativeLayout.LayoutParams(-1, -1));
        relativeLayout.setPadding(3, 0, 3, 3);
        relativeLayout.setVerticalGravity(10);
		RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-2, -2);
        layoutParams.addRule(11);

        //TitanicButton close = new TitanicButton(this);
        close = new Button(this);
        close.setText((("Close")));
        close.setTextSize(15.0f);
        close.setLayoutParams(new LinearLayout.LayoutParams(dp(100), 65));
        close.setTextColor(Color.parseColor("RED"));
        close.setBackgroundColor(Color.TRANSPARENT);
        close.setLayoutParams(layoutParams);
        close.setPadding(5, 0, 5, 0);

        //


        //TitanicButton close = new TitanicButton(this);

		kill = new Button(this);
        kill.setText((("Inject")));
        kill.setTextSize(12.0f);
        kill.setTextColor(Color.parseColor("WHITE"));
        kill.setBackgroundColor(Color.TRANSPARENT);
        kill.setPadding(5, 0, 5, 0);

		
		///)/relativeLayout.addView(close);

		//relativeLayout.addView(kill);
		
        //
		relativeLayout.addView(kill);
		relativeLayout.addView(close);

        rootFrame.setLayoutParams(new FrameLayout.LayoutParams(-1, -1));
        mRootContainer.setLayoutParams(new FrameLayout.LayoutParams(-2, -2));
        mCollapsed.setLayoutParams(new RelativeLayout.LayoutParams(-2, -2));
        mCollapsed.setVisibility(View.VISIBLE);

        //ShimmerButton startimage =new ShimmerButton(this);
        startimage = new ImageView(getBaseContext());
        startimage.setLayoutParams(new RelativeLayout.LayoutParams(-2, -2));
        int applyDimension = (int) TypedValue.applyDimension(1, (float) 50, getResources().getDisplayMetrics());
        startimage.getLayoutParams().height = applyDimension;
        startimage.getLayoutParams().width = applyDimension;
        startimage.requestLayout();
        startimage.setScaleType(ImageView.ScaleType.FIT_XY);
        byte[] decode = Base64.decode(Icon(), 0);
        startimage.setImageBitmap(BitmapFactory.decodeByteArray(decode, 0, decode.length));
		startimage.setImageAlpha(200);


	    ((ViewGroup.MarginLayoutParams) startimage.getLayoutParams()).topMargin = convertDipToPixels(10);

		
        mExpanded.setVisibility(View.GONE);
        mExpanded.setAlpha(0.95f);
        mExpanded.setGravity(17);
        mExpanded.setOrientation(LinearLayout.VERTICAL);
        mExpanded.setPadding(0, 0, 0, 0);
        mExpanded.setLayoutParams(new LinearLayout.LayoutParams(dp(250), dp(-2)));
        mExpanded.setPadding(10, 5, 10, 10);
		mExpanded.setBackgroundColor(Color.parseColor("GREY"));
		GradientDrawable BackgroundCaixa = new GradientDrawable();
        BackgroundCaixa.setShape(0);
        BackgroundCaixa.setColor(Color.BLACK);
        BackgroundCaixa.setCornerRadius((float) dp(10));
        BackgroundCaixa.setSize(dp(20), dp(20));
        BackgroundCaixa.setStroke(dp(2), Color.WHITE);






        final ScrollView scrollView = new ScrollView(getBaseContext());
        scrollView.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(152)));

        patches.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
        patches.setOrientation(LinearLayout.VERTICAL);
        mButtonPanel.setLayoutParams(new LinearLayout.LayoutParams(-2, -2));


        //ShimmerButton startimage =new ShimmerButton(this);
        musk = new ImageView(getBaseContext());
        musk.setLayoutParams(new RelativeLayout.LayoutParams(-2, -2));
        musk.getLayoutParams().height = dp(50);
        musk.getLayoutParams().width = dp(50);

		musk.requestLayout();
        musk.setScaleType(ImageView.ScaleType.FIT_XY);
        byte[] titleimg = Base64.decode(Icon(), 0);
        musk.setImageBitmap(BitmapFactory.decodeByteArray(titleimg, 0, titleimg.length));




        // new Shimmer().start(startimage);
        ((ViewGroup.MarginLayoutParams) startimage.getLayoutParams()).topMargin = convertDipToPixels(10);



		LinearLayout MuskLayout = new LinearLayout(this);
		// MuskLayout.setGravity(Gravity.CENTER);
        MuskLayout.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));

        //********** Settings icon ******
        //********** Settings icon **********
        TextView settings = new TextView(getBaseContext());
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            settings.setText("\uD83D\uDD27");
        } else {
            settings.setText("\uD83D\uDD27"); //Android 5 and below can't display ⚙ emoji so display "🔧" instead
        }
        settings.setTextColor(Color.parseColor("#82CAFD"));
        settings.setTypeface(Typeface.DEFAULT_BOLD);
        settings.setTextSize(20.0f);

		settings.setPadding(5, 0, 5, 0);

		RelativeLayout.LayoutParams rlsettings = new RelativeLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT);
        rlsettings.addRule(RelativeLayout.ALIGN_PARENT_RIGHT);
        settings.setLayoutParams(rlsettings);
        settings.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {

					scrollView.removeView(patches);
					//scrollView.addView(mSettings);
					mExpanded.addView(close);

					
					
				}
			});


        //********** Settings ******
        mSettings = new LinearLayout(getBaseContext()); // Menu markup (when the menu is expanded)
        mSettings.setOrientation(LinearLayout.VERTICAL);


        //Title text

		LinearLayout TitleLayout = new LinearLayout(this);
        //TitleLayout.setGravity(Gravity.CENTER);
        TitleLayout.setOrientation(2);
        TitleLayout.setGravity(2);
        TitleLayout.setLayoutParams(new LinearLayout.LayoutParams(layoutParams.FILL_PARENT, -1));


        // textView = new ShimmerTextView(this);
		 textView = new TextView(getBaseContext());
      
		
		StringBuilder mm = new StringBuilder();
		
	
		
		
		
		
		textView.setText(Title());
        textView.setTextColor(Color.parseColor((("RED"))));
         textView.setTextSize(18.0f);
        textView.setPadding(5, 5, 5, 5);
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-2, -2);
        layoutParams2.gravity = 17;
		textView.setLayoutParams(layoutParams2);


		
		
			
		
        LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(layoutParams.FILL_PARENT, -1);
        layoutParams3.gravity = 17;
        new LinearLayout.LayoutParams(-1, dp(25)).topMargin = dp(2);
        rootFrame.addView(mRootContainer);
        mRootContainer.addView(mCollapsed);
        mRootContainer.addView(mExpanded);
        mExpanded.addView(MuskLayout);

        MuskLayout.addView(musk);
		TitleLayout.addView(textView);
		MuskLayout.addView(TitleLayout);

		mExpanded.addView(mSettings);

        mExpanded.addView(scrollView);
        mCollapsed.addView(startimage);
        scrollView.addView(patches);
		
		

        mExpanded.addView(relativeLayout);
        mFloatingView = rootFrame;
        if (Build.VERSION.SDK_INT >= 26) {
            params = new WindowManager.LayoutParams(-2, -2, 2038, 8, -3);
        } else {
            params = new WindowManager.LayoutParams(-2, -2, 2002, 8, -3);
        }
        WindowManager.LayoutParams layoutParams4 = params;
        layoutParams4.gravity = 51;
        layoutParams4.x = 0;
        layoutParams4.y = 100;
        mWindowManager = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        mWindowManager.addView(mFloatingView, params);
        RelativeLayout relativeLayout2 = mCollapsed;
        LinearLayout linearLayout = mExpanded;
        mFloatingView.setOnTouchListener(onTouchListener());
        startimage.setOnTouchListener(onTouchListener());
        musk.setOnTouchListener(onTouchListener());
        initMenuButton(relativeLayout2, linearLayout);
	
		DrawCanvas();
    
    }
	private void initMenuButton(final View view2, final View view3) {
        startimage.setOnClickListener(new View.OnClickListener() {
				public void onClick(View view) {
					view2.setVisibility(View.GONE);
					view3.setVisibility(View.VISIBLE);
				}
			});
        

        close.setOnClickListener(new View.OnClickListener() {
				public void onClick(View view) {
					view2.setVisibility(View.VISIBLE);
					view2.setAlpha(0.95f);
					view3.setVisibility(View.GONE);
				}

			});
		kill.setOnClickListener(new View.OnClickListener() {
				public void onClick(View view) {
					Inject();
					kill.setVisibility(View.GONE);
				}

			});
		
		
			
			

    }
    private View.OnTouchListener onTouchListener() {
        return new View.OnTouchListener() {
            final View collapsedView = mCollapsed;
            final View expandedView = mExpanded;
            private float initialTouchX;
            private float initialTouchY;
            private int initialX;
            private int initialY;

            public boolean onTouch(View view, MotionEvent motionEvent) {
                switch (motionEvent.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        initialX = params.x;
                        initialY = params.y;
                        initialTouchX = motionEvent.getRawX();
                        initialTouchY = motionEvent.getRawY();
                        return true;
                    case MotionEvent.ACTION_UP:
                        int rawX = (int) (motionEvent.getRawX() - initialTouchX);
                        int rawY = (int) (motionEvent.getRawY() - initialTouchY);

                        //The check for Xdiff <10 && YDiff< 10 because sometime elements moves a little while clicking.
                        //So that is click event.
                        if (rawX < 10 && rawY < 10 && isViewCollapsed()) {
                            //When user clicks on the image view of the collapsed layout,
                            //visibility of the collapsed layout will be changed to "View.GONE"
                            //and expanded view will become visible.
                            collapsedView.setVisibility(View.GONE);
                            expandedView.setVisibility(View.VISIBLE);

                            //Toast.makeText(FloatingModMenuService.this, Html.fromHtml(Toast()), Toast.LENGTH_SHORT).show();
                        }
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        //Calculate the X and Y coordinates of the view.
                        params.x = initialX + ((int) (motionEvent.getRawX() - initialTouchX));
                        params.y = initialY + ((int) (motionEvent.getRawY() - initialTouchY));
                        //Update the layout with new X & Y coordinate
                        mWindowManager.updateViewLayout(rootFrame, params);
                        return true;
                    default:
                        return false;
                }
            }
        };
    }

    private void CreateMenuList() {
        String[] listFT = MenuPro();
        for (int i = 0; i < listFT.length; i++) {
            final int feature = i;
            String str = listFT[i];
            if (str.contains("Toggle_")) {
				addSwitch(str.replace("Toggle_", ""), new InterfaceBool() {
						public void OnWrite(boolean z) {
							Changes(feature, 0);
						}
					});
            } else if (str.contains("SeekBar_")) {
                String[] split = str.split("_");
                addSeekBar(split[1], Integer.parseInt(split[2]), Integer.parseInt(split[3]), new InterfaceInt() {
						public void OnWrite(int i) {
							Changes(feature, i);
						}
					});
            }
			else if (str.contains("Spot_")) {
                String[] split = str.split("_");
                addAimSpot(split[1], Integer.parseInt(split[2]), Integer.parseInt(split[3]), new InterfaceInt() {
						public void OnWrite(int i) {
							Changes(feature, i);
						}
					});
            }
			else if (str.contains("Category_")) {
                addCategory(str.replace("Category_", ""));
            } else if (str.contains("Button_")) {
                addButton(str.replace("Button_", ""), new InterfaceBtn() {
						public void OnWrite() {
							Changes(feature, 0);
						}
					});
            }
        }
    }
	
	
	
	public int Game(String pkg) {
		try {
			ArrayList arrayList = new ArrayList();
			Shell.PoolWrapper poolWrapper = Shell.Pool.SU;
			poolWrapper.run("(toolbox ps; toolbox ps -A; toybox ps; toybox ps -A) | grep \" " + pkg + "$\"", arrayList, null, false);
			Iterator iterator = arrayList.iterator();
			while (iterator.hasNext()) {
				String Trim = ((String) iterator.next()).trim();
				while (Trim.contains("  ")) {
					Trim = Trim.replace("  ", " ");
				}
				String[] Split = Trim.split(" ");
				if (Split.length >= 2) {
					return Integer.parseInt(Split[1]);
				}
			}
			return -1;
		} catch (Shell.ShellDiedException e) {
			e.printStackTrace();
			return -1;
		}
	}
	
	
	public Boolean Inject(){
		
		
		
		
		try {

			String target = "com.dts.freefireth";

			
			String injector = this.getApplicationInfo().nativeLibraryDir + File.separator + "libinject.so";
			new File(injector).setExecutable(true);
			String payload_source = this.getApplicationInfo().nativeLibraryDir + File.separator + "libmusk.so";

			String payload_dest = "/data/local/tmp/libmusk.so";
			String context = "u:object_r:system_lib_file:s0";

			List<String> STDOUT = new ArrayList<>();
			Shell.Pool.SU.run("ls -lZ /system/lib/libandroid_runtime.so", STDOUT, null, false);
			for (String line : STDOUT) {
				if (line.contains(" u:object_r:") && line.contains(":s0 ")) {
					context = line.substring(line.indexOf("u:object_r:"));
					context = context.substring(0, context.indexOf(' '));
				}
			}

			Shell.Pool.SU.run(new String[] {"cp " + payload_source + " " + payload_dest, "chmod 777 " + payload_dest});

			
			// get pid for target
			int pid = Game(target);
			if (pid < 0) {
				return true;
			}

			Shell.Pool.SU.run((Object) String.format("%s %d %s", new Object[]{injector, Integer.valueOf(pid), payload_dest}));
			new File(payload_dest).delete();

			
			if (RunnigTask.Init() < 0) {
				Toast.makeText(this, "Injection Failed!", Toast.LENGTH_SHORT).show();
				addCategory2();
		    	addCategory("<b>ABI:</b><font color='#00FF00'>" + getArch(getApplicationInfo().nativeLibraryDir) + "</font>");
				
				addCategory(("<b>MODEL:</b><font color='#00FF00'>" + Build.MODEL + "</font>"));
				
			} else {
				
			 
		       Toast.makeText(this, "Injection Sucessful", 1).show();
				
	            addCategory2();
				addCategory("<b>ABI:</b><font color='#00FF00'>" + getArch(getApplicationInfo().nativeLibraryDir) + "</font>");
				
                addCategory(("<b>MODEL:</b><font color='#00FF00'>" + Build.MODEL + "</font>"));
				
				CreateMenuList();
		 		}
			return true;
		} catch (Exception e) {
			
			
			
			return null;
		}
		
	}
	
	private View ButtonLink(final String featureName, final String url) {
        final Button button = new Button(this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT);
        layoutParams.setMargins(7, 5, 7, 5);
        button.setLayoutParams(layoutParams);
        button.setAllCaps(false); //Disable caps to support html
        button.setTextColor(Color.WHITE);
        button.setGravity(Gravity.CENTER);
        button.setText(featureName);
        button.setBackgroundColor(Color.TRANSPARENT);
        button.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					Intent intent = new Intent(Intent.ACTION_VIEW);
					intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
					intent.setData(Uri.parse(url));
					startActivity(intent);
				}
			});
        return button;
    }
    public void addButton(String feature, final InterfaceBtn interfaceBtn) {
        final Button button = new Button(this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -1);
        layoutParams.setMargins(7, 5, 7, 5);
        button.setLayoutParams(layoutParams);
        button.setPadding(10, 5, 10, 5);
        button.setTextSize(13.0f);
        button.setTextColor(Color.parseColor("#D5E3EB"));
        button.setGravity(17);

        if (feature.contains("OnOff_")) {
            feature = feature.replace("OnOff_", "");
            button.setText(feature + ": OFF");
            button.setBackgroundColor(Color.parseColor("#7f0000"));
            final String feature2 = feature;
            button.setOnClickListener(new View.OnClickListener() {
					private boolean isActive = true;

					public void onClick(View v) {
						interfaceBtn.OnWrite();
						if (isActive) {
							button.setText(feature2 + ": ON");
							button.setBackgroundColor(Color.parseColor("#003300"));
							isActive = false;
							return;
						}
						button.setText(feature2 + ": OFF");
						button.setBackgroundColor(Color.parseColor("#7f0000"));
						isActive = true;
					}
				});
        } else {
            button.setText(feature);
            button.setBackgroundColor(Color.parseColor("#1C262D"));
            final String feature2 = feature;
            button.setOnClickListener(new View.OnClickListener() {
					public void onClick(View v) {
						interfaceBtn.OnWrite();
					}
				});
        }
        patches.addView(button);
    }

    private void addCategory(String text) {
        TextView textView = new TextView (this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -1);
        layoutParams.setMargins(2, 2, 2, 2);
        textView.setText(Html.fromHtml("<font face='monospace'><b>" + text + "</b></font>"));
        textView.setLayoutParams(layoutParams);

        textView.setGravity(17);
        textView.setTextSize(15.0f);
        textView.setShadowLayer(30.0f, 12.0f, 12.0f, Color.parseColor("RED"));
        textView.setTextColor(Color.parseColor("WHITE"));
        textView.setPadding(10, 5, 0, 5);
        patches.addView(textView);
    }
	
	private void addCategory2() {
        TextView textView = new TextView (this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -1);
        layoutParams.setMargins(2, 2, 2, 2);
           textView.setLayoutParams(layoutParams);
		if (IsConnected()) {
			textView.setText(Html.fromHtml("<b>Status : </b><font color='#00FF00'>Online</font>"));
		} else {
			textView.setText(Html.fromHtml("<b>Status : </b><font color='#de0c0c'>Offline</font>"));
		}
		
		
		
		
        textView.setGravity(17);
        textView.setTextSize(15.0f);
        textView.setShadowLayer(30.0f, 12.0f, 12.0f, Color.parseColor("RED"));
        textView.setTextColor(Color.parseColor("WHITE"));
        textView.setPadding(10, 5, 0, 5);
        patches.addView(textView);
    }
	
	

	
	
    @SuppressLint("WrongConstant")
    private void addSwitch(String str, final InterfaceBool sw) {
		Switch sww = new Switch(this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
        layoutParams.leftMargin = dp(5);
        layoutParams.rightMargin = dp(6);
        layoutParams.topMargin = dp(5);
        layoutParams.bottomMargin = dp(5);
        sww.setText(str);
        sww.setTextColor(Color.WHITE);
        sww.setLayoutParams(layoutParams);
        sww.setTextSize(2, 15.0f);
        final GradientDrawable BackgroundCaixa = new GradientDrawable();
        BackgroundCaixa.setShape(0);
        BackgroundCaixa.setColor(-1);
        BackgroundCaixa.setCornerRadius((float) dp(10));
        BackgroundCaixa.setSize(dp(20), dp(20));
        BackgroundCaixa.setStroke(dp(1), Color.CYAN);
        final GradientDrawable BackgrounSwitch = new GradientDrawable();
        BackgrounSwitch.setShape(0);

        BackgrounSwitch.setColor( Color.parseColor("GREEN"));
        BackgrounSwitch.setStroke(dp(1), Color.RED);
        BackgrounSwitch.setCornerRadius((float) dp(10));
        BackgrounSwitch.setSize(dp(20), dp(20));
        sww.setTrackDrawable(BackgroundCaixa);
        sww.setThumbDrawable(BackgrounSwitch);
        sww.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					sw.OnWrite(isChecked);
					if (isChecked) {
						BackgrounSwitch.setStroke(dp(1), Color.parseColor("#FF0044"));
						BackgroundCaixa.setStroke(dp(1), Color.parseColor("#FF0044"));
						BackgroundCaixa.setColor(Color.parseColor("YELLOW"));
						return;
					}
					BackgrounSwitch.setStroke(dp(1), Color.BLUE);
					BackgroundCaixa.setStroke(dp(1), Color.BLUE);
					BackgroundCaixa.setColor(Color.BLUE);
				}
			});
        this.patches.addView(sww);

    }
	public void showNoRootMessage() {
        (new AlertDialog.Builder(this))
			.setMessage("Could not acquire root")
			.setNegativeButton(android.R.string.ok, null)
			.show();
    } 


    @SuppressLint("WrongConstant")
    private void addSeekBar(String str, int progress, int max, InterfaceInt sb) {
        LinearLayout linearLayout = new LinearLayout(this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -1);
        layoutParams.setMargins(2, 2, 2, 2);
        linearLayout.setPadding(10, 5, 0, 5);
        linearLayout.setOrientation(1);
        linearLayout.setGravity(17);
        linearLayout.setLayoutParams(layoutParams);
        TextView textView = new TextView(this);
        StringBuilder sb2 = new StringBuilder();
        sb2.append("<font typeface='features.ttf'><b>");
        sb2.append(str);
        sb2.append("<font typeface='features.ttf'><b>" + ": <font color='BLACK'>" + "</b></font>");
        sb2.append(progress);
        sb2.append("</b></font>");
        textView.setText(Html.fromHtml(sb2.toString()));

        textView.setTextColor(Color.WHITE);
     //   textView.setTypeface(Typefaces.get(this, "font.ttf"));

		final SeekBar seekBar = new SeekBar(this);
		final GradientDrawable Background_seek = new GradientDrawable();
        Background_seek.setShape(0);
        Background_seek.setColor(-1);
        Background_seek.setStroke(dp(1), Color.CYAN);
        Background_seek.setCornerRadius((float) dp(10));
        Background_seek.setSize(dp(20), dp(20));


		LinearLayout.LayoutParams SBarParams = new LinearLayout.LayoutParams(-1, dp(20));
        SBarParams.leftMargin = dp(5);
        SBarParams.rightMargin = dp(5);
        SBarParams.bottomMargin = dp(5);
        seekBar.setLayoutParams(SBarParams);
        seekBar.setMax(max);
        seekBar.setThumb(Background_seek);
        seekBar.getProgressDrawable().setColorFilter(Color.parseColor("#0040ff"), PorterDuff.Mode.MULTIPLY);


		if (Build.VERSION.SDK_INT >= 21) {
            seekBar.getProgressDrawable().setTint(-1);
        }
        seekBar.setMax(max);
        seekBar.setProgress(progress);
        final int i5 = progress;
        final SeekBar seekBar2 = seekBar;
        final InterfaceInt sb3 = sb;   
        final TextView textView2 = textView;
        final String str3 = str;
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {

				private String itv;
				public void onStartTrackingTouch(SeekBar seekBar) {
				}

				public void onStopTrackingTouch(SeekBar seekBar) {
				}

				public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
					int i2 = i5;
					if (i < i2) {
						seekBar2.setProgress(i2);
						sb3.OnWrite(i5);
						TextView textView = textView2;
						textView2.setText(Html.fromHtml("<font typeface='features.ttf'><b>" + str3 + ": <font color=BLACK'>" + i5 + "</b></font>"));
						Background_seek.setColor(-1);
						Background_seek.setStroke(dp(1), Color.parseColor("#FF6600"));
						seekBar.getProgressDrawable().setColorFilter(Color.parseColor("#FF6600"), PorterDuff.Mode.MULTIPLY);

						return;
					}
					sb3.OnWrite(i);
					textView2.setText(Html.fromHtml("<font typeface='features.ttf'><b>" + str3 + ": <font color=BLACK'>" + i + "</b></font>"));
					Background_seek.setColor(-1);
					Background_seek.setStroke(dp(1), Color.CYAN);
					seekBar.getProgressDrawable().setColorFilter(Color.parseColor("#FF6600"), PorterDuff.Mode.MULTIPLY);

				}
			});

        linearLayout.addView(textView);
        linearLayout.addView(seekBar);
        this.patches.addView(linearLayout);
    }

	@SuppressLint("WrongConstant")
    private void addAimSpot(String str, int progress, int max, InterfaceInt sb) {
        LinearLayout linearLayout = new LinearLayout(this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -1);
        layoutParams.setMargins(2, 2, 2, 2);
        linearLayout.setPadding(10, 5, 0, 5);
        linearLayout.setOrientation(1);
        linearLayout.setGravity(17);
        linearLayout.setLayoutParams(layoutParams);
        TextView textView = new TextView(this);
        StringBuilder sb2 = new StringBuilder();
        sb2.append("<font typeface='features.ttf'><b>");
        sb2.append(str);
        sb2.append("<font typeface='features.ttf'><b>" + ": <font color='BLACK'>" + "</b></font>");
        sb2.append("Deactivated");
        sb2.append("</b></font>");
        textView.setText(Html.fromHtml(sb2.toString()));

        textView.setTextColor(Color.WHITE);
        //textView.setTypeface(Typefaces.get(this, "font.ttf"));

		final SeekBar seekBar = new SeekBar(this);
		final GradientDrawable Background_seek = new GradientDrawable();
        Background_seek.setShape(0);
        Background_seek.setColor(-1);
        Background_seek.setStroke(dp(1), Color.CYAN);
        Background_seek.setCornerRadius((float) dp(10));
        Background_seek.setSize(dp(20), dp(20));


		LinearLayout.LayoutParams SBarParams = new LinearLayout.LayoutParams(-1, dp(20));
        SBarParams.leftMargin = dp(5);
        SBarParams.rightMargin = dp(5);
        SBarParams.bottomMargin = dp(5);
        seekBar.setLayoutParams(SBarParams);
        seekBar.setMax(max);
        seekBar.setThumb(Background_seek);
        seekBar.getProgressDrawable().setColorFilter(Color.parseColor("#0040ff"), PorterDuff.Mode.MULTIPLY);


		if (Build.VERSION.SDK_INT >= 21) {
            seekBar.getProgressDrawable().setTint(-1);
        }
        seekBar.setMax(max);
        seekBar.setProgress(progress);
        final int i5 = progress;
        final SeekBar seekBar2 = seekBar;
        final InterfaceInt sb3 = sb;
        final TextView textView2 = textView;
        final String str3 = str;
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {

				private String itv;
				public void onStartTrackingTouch(SeekBar seekBar) {
				}

				public void onStopTrackingTouch(SeekBar seekBar) {
				}

				public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
					int i2 = i5;
					if (i == 0 ) {
						seekBar2.setProgress(i2);
						sb3.OnWrite(i5);
						TextView textView = textView2;
						textView2.setText(Html.fromHtml("<font typeface='features.ttf'><b>" + str3 + ": <font color=BLACK'>" + "Deactivated" + "</b></font>"));
						Background_seek.setColor(-1);
						Background_seek.setStroke(dp(1), Color.parseColor("#FF6600"));
						seekBar.getProgressDrawable().setColorFilter(Color.parseColor("#FF6600"), PorterDuff.Mode.MULTIPLY);

						return;
					}else if (i == 1){
						sb3.OnWrite(i5);
						TextView textView = textView2;
						textView2.setText(Html.fromHtml("<font typeface='features.ttf'><b>" + str3 + ": <font color=BLACK'>" + "Head" + "</b></font>"));
						Background_seek.setColor(-1);
						Background_seek.setStroke(dp(1), Color.parseColor("#FF6600"));
						seekBar.getProgressDrawable().setColorFilter(Color.parseColor("#FF6600"), PorterDuff.Mode.MULTIPLY);


					}else if (i == 2){
						sb3.OnWrite(i5);
						TextView textView = textView2;
						textView2.setText(Html.fromHtml("<font typeface='features.ttf'><b>" + str3 + ": <font color=BLACK'>" + "Hip" + "</b></font>"));
						Background_seek.setColor(-1);
						Background_seek.setStroke(dp(1), Color.parseColor("#FF6600"));
						seekBar.getProgressDrawable().setColorFilter(Color.parseColor("#FF6600"), PorterDuff.Mode.MULTIPLY);


					}
					else if (i == 3){
						sb3.OnWrite(i5);
						textView2.setText(Html.fromHtml("<font typeface='features.ttf'><b>" + str3 + ": <font color=BLACK'>" + "Leg" + "</b></font>"));
						Background_seek.setColor(-1);
						Background_seek.setStroke(dp(1), Color.CYAN);
						seekBar.getProgressDrawable().setColorFilter(Color.parseColor("#FF6600"), PorterDuff.Mode.MULTIPLY);

					}
				}
			});

        linearLayout.addView(textView);
        linearLayout.addView(seekBar);
        this.patches.addView(linearLayout);
    }

	
	public boolean isViewCollapsed() {
        return rootFrame == null || mCollapsed.getVisibility() == View.VISIBLE;
    }

    //For our image a little converter
    private int convertDipToPixels(int i) {
        return (int) ((((float) i) * getResources().getDisplayMetrics().density) + 0.5f);
    }

    private int dp(int i) {
        return (int) TypedValue.applyDimension(1, (float) i, getResources().getDisplayMetrics());
    }

    //Destroy our View
    public void onDestroy() {
        super.onDestroy();
        View view = rootFrame;
        if (view != null) {
            mWindowManager.removeView(view);
        }
        ESPView eSPView = this.overlayView;
        if (eSPView != null) {
            this.mWindowManager.removeView(eSPView);
            this.overlayView = null;
        }
		Stop();
    }

    //Check if we are still in the game. If now our Menu and Menu button will dissapear
    

    //Same as above so it wont crash in the background and therefore use alot of Battery life
    public void onTaskRemoved(Intent intent) {
        stopSelf();
        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        super.onTaskRemoved(intent);
    }

  
    private interface InterfaceBtn {
        void OnWrite();
    }

    private interface InterfaceInt {
        void OnWrite(int i);
    }

    private interface InterfaceBool {
        void OnWrite(boolean z);
    }

    private interface InterfaceStr {
        void OnWrite(String s);
    }
}
